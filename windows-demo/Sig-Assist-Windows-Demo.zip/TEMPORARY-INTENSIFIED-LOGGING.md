# TEMPORARY INTENSIFIED LOGGING — REMOVAL PRIORITY: HIGH

The separate SIG refinement dataset is described in `SIG-DATASET.md`. It is independent of this temporary metadata recorder and has separate IndexedDB storage and capture controls. Removing the temporary recorder must preserve shared UI Automation cache helpers used by `DatasetSnapshot`, or replace those dependencies explicitly; do not silently remove dataset collection with the recorder.

**TEMPORARY_INTENSIFIED_LOGGING_REMOVAL_PRIORITY_HIGH**

Prototype v0.1.9. Remove or substantially reduce this recorder once the E-Rx investigation has supplied the required evidence. The investigation may span many releases; this marker has no automatic expiry date. Review it before every production release. Preserve useful technician feedback and an appropriate operational audit when removing experimental capture.

## Record a session

1. Extract the workstation update over the existing Sig-Assist folder. Its existing `iguana-site.json` is preserved. Close the old connector, then use `Start-Sig-Assist.bat` (or `Start-Iguana-Connector.bat`).
2. Open **Temporary intensified logging** beneath the app header. Choose the Framework entry window, or reuse the window already selected through Find E-Rx. Explicit selection uses the existing eight-second window-choice workflow and can perform the normal active PON read. Once selected, periodic observation is passive.
3. Click **Start pilot recording**. Check the displayed recording folder and observer status. Each recording gets a new dated/unique child folder under the configured root. A recording can collect browser/connector events before a Framework window is selected; `SELECTION_REQUIRED` explicitly identifies that gap.
4. Work normally. Checkpoints are optional: mark one **after the action finishes and the screen settles**, not before or during it. Choose **Saved** only after Framework finishes saving. Duplicate or mistimed checkpoints do not invalidate the automatic recording. Use Feedback for comments. A checkpoint is your observation, not machine verification of a prescription save.
5. Click **Stop and save recording**, wait for the pending browser count to reach zero, then **Save review bundle in recording folder**. The bundle is written beside that session's log parts, not to the browser's Downloads folder. Check any failure/drop notices before sharing. The final bundle contains the saved parts; you normally only need to share that bundle. Keep the parts locally for recovery.

The amber panel identifies temporary logging everywhere in the app, including while recording. Red notices report file failures, limits, dropped events, unavailable browser backup, and unsaved events. Logging starts only on explicit request. It does not resume automatically after a connector restart.

## Destination — configured roots only

The supplied workstation update includes a private `pilot-log-location.json` containing the technician's requested UNC root followed by its mapped-drive alternative. The connector tries them in order, creates a session subfolder under the first writable existing root, and displays the exact selected path. It never silently redirects to AppData, TEMP, the source checkout, or Downloads when those roots are unavailable.

Mapped drive letters must exist in the same Windows/Citrix session as the connector. An unavailable UNC path does not establish that its mapped alternative is mounted. Actual share permissions and drive mapping require the workstation check; CI validates the configured-root/failure behavior with temporary synthetic directories.

Generic deployments can configure `directories` in `pilot-log-location.json` beside the connector or set `SIG_ASSIST_PILOT_LOG_DIR` before starting it. Do not put patient identifiers into paths or configuration. Workstation-specific path configuration stays outside the public repository. An unconfigured generic build leaves Start disabled with an explanation.

## Information collected

- A manifest with session/build, runtime/platform, start/stop state, limits, saved/drop counts, and the temporary removal marker.
- Separate workflow and translation JSONL files. Live trace subscribers capture metadata before the old 1,000-event display ring can discard events. A burst in one stream cannot consume the other stream's file budget.
- Browser screen changes, button/input interaction types, non-password value lengths, visibility/lifecycle/error occurrence, customization counts, and pilot feedback-save metadata. No raw DOM labels, values, exception messages, URLs, input keys, or clipboard data are captured by this recorder.
- Translation layer/component/severity, per-page anonymous trace references, counts/flags, and relevant string lengths. Original directions, output SIG strings, drugs, PONs and ordinary raw trace details are excluded from the new journal.
- Local connector and desktop operation boundaries, timings, safe outcomes, uncertainty/read-back flags, and keyed PON references when the existing operation supplies a PON. Recording never starts another Iguana query.
- Approximately every three seconds, a passive snapshot of the remembered Framework window's currently exposed control tree: known control IDs, type/family, hierarchy, focus/enabled/read-only/toggle/selection state, surveyed capability counts, advertised grid dimensions, string lengths and keyed change tokens. `patterns` and `patternCount` survey only Value, Toggle, SelectionItem and Grid availability; they are not a complete UIA pattern inventory. Subsequent snapshots contain changed/removed controls plus a summary.

Only a fixed vocabulary of ordinary field/button labels is retained, such as quantity, package type, start date, SIG, Next and Save. Control bounds help align those fields with PSR screenshots. Arbitrary names/values, unknown automation IDs and window titles are represented by per-recording HMAC tokens using a key kept only in connector memory. Tokens allow change detection and are not patient identifiers or a complete anonymization claim. They cannot reconstruct a SIG or validate its meaning. Tokens differ across new recordings. Snapshot observation time is separate from file-write time. Review exports before sharing. Regular Trace Logs, feedback comments, desktop diagnostic exports and PSR files retain their separately documented broader contents.

## Passive observation boundaries

The new `observe` action validates the remembered process start/window identity. It never discovers a different window on failure, reads other Framework instances, moves focus, activates a window, scrolls, realizes virtual cells, changes accessibility settings, invokes a control, or writes a field. Password controls and descendants are skipped. Native snapshots are bounded to 800 captured controls, 1,600 visited nodes, depth 24 and a 1.2-second cooperative budget. The helper has an eight-second outer timeout. Unsupported providers, busy clinical operations, unavailable windows and partial snapshots are reported.

Identity, runtime IDs and four capability-availability flags are cached per element. A validated focused parent or known view can also use one shallow element-and-immediate-children identity cache, with critical editors read before deeper traversal; there is no whole-window subtree cache. Values are fetched in a separate fresh, element-only read after password/process/visibility checks. No values are reused between samples. Up to 250ms of the existing 1.2-second budget can seed the validated focused field, its parent and nearest known view. Standard UIA Boolean defaults are preserved for non-edit containers, so an omitted IsPassword=false property does not prune their children; actual password controls remain excluded. Offscreen layout wrappers remain traversable, while their own values are excluded. A connector-owned `scanOffset` rotates sibling starting positions across snapshots; browser-supplied offsets are ignored. Summary counters `scanOffset`, `cacheReads` and `prioritySeeds` distinguish traversal rotation, cache reads and accepted focus/view seeds. Provider calls can overrun the cooperative deadline; these counters do not establish workstation latency or complete field coverage.

The Windows synthetic smoke fixture adds 1,000 decorative controls plus quantity, days supply, package type and start-date editors. Its assertions check field reach, changed quantity tokens, unchanged focus and omitted password/hidden values. Windows compilation and UI Automation execution remain required; source inspection and Linux connector tests do not establish those results. Keep `TEMPORARY_INTENSIFIED_LOGGING_REMOVAL_PRIORITY_HIGH` visible while this investigation continues.

Only descendants of the selected window are read; separate top-level dialogs and offscreen/virtualized content may be absent. This first observer is a state sampler, not a complete click recorder or event subscription: changes between samples can be missed. PSR and technician comments remain useful. No claim of a completed clinical save is derived from a changed screen or value token.

## Durability and limits

The next prototype source also records fixed `failureReason` categories and a
bounded `helperDurationMs` when a passive helper fails. Categories distinguish
timeout, invalid output, process exit, startup failure and unknown failure.
Neither raw exception messages nor stdout/stderr/path text are exported with
these observer failures. The delivered v0.1.9 ZIP predates this diagnostic
addition; its generic OBSERVATION_FAILED cannot establish why a helper failed.

Each stream rotates at 2 MB and retains up to 64 MB per recording. A recording has an eight-hour monotonic duration limit; start another to continue. Neither rotation nor starting another session deletes older files. Keep recordings as long as the investigation needs them, then remove them deliberately.

File appends are serialized; accepted browser batches are synced before acknowledgment. Retries use a persisted batch ID, which the connector acknowledges once during that session. Export/bundle operations take a consistent snapshot of acknowledged files. A combined bundle groups log parts; use the global `seq` field to reconstruct cross-stream order. UTC times, timezone offsets and monotonic elapsed times distinguish midnight and wall-clock changes.

The browser keeps separate bounded pending queues (10,000 events per stream) and backs up pending batches at flush/page-hide boundaries. Acknowledgment failures retain the same batch for retry. Reloading the same browser origin while the same connector remains running restores that outbox. A forced process/browser termination before backup/flush can lose the newest pending events; this is not reported as durable file capture. Pending buffers now use a dedicated IndexedDB database rather than localStorage, so they do not consume the localStorage quota used by reports and customizations. Legacy diagnostic buffers are removed from localStorage only after a committed, read-back-verified database copy; corrupt legacy buffers are preserved. Reports, custom SIG codes, orders and other browser keys are never deleted by that migration. Browser database storage still has limits and can be unavailable; failures and corrupt buffers are flagged. An asynchronous page-hide backup is best effort, so stopping and flushing before closing remains necessary. A per-stream file limit drops further events in that stream with explicit counters. Translation overflow cannot evict workflow files. Browser drop counters are separate from file drop counters and are included in the manifest; zero file drops alone does not establish a complete browser capture. Pending queue status and persistence apply to the same browser origin, including its port. Queue status and persistence no longer translate every unapproved waiting order; the active order and reviewed split parts still use the clinical engine.

Do not close an old connector before stopping/saving/exporting its recording. A forced connector exit may leave a manifest marked active; synced JSONL parts remain in the displayed folder. Previous-session folders are not auto-reopened or auto-deleted by the next connector. The emergency **Download pending browser events** action uses the browser's save location; explicitly select the recording folder for that manual fallback.

## Removal work

Search source and artifacts for `TEMPORARY_INTENSIFIED_LOGGING_REMOVAL_PRIORITY_HIGH`. Review/remove the UI panel, live trace subscription/outbox, bridge journal endpoints/timer, native observer, private destination configuration, file retention/bundles, packaging additions and associated pilot checks. Removing this recorder must not remove ordinary SIG translation, reviewed field transfer, technician feedback, or normal error reporting. The marker is deliberately prominent; it is not a build-time production exclusion.

## Discrepancy save recovery in v0.1.8

Discrepancy reports retain the connected-folder/localStorage paths and gain a separate local IndexedDB fallback if neither can accept a write. The archive merges local sources by report ID; archiving/restoring records a newer storage timestamp to supersede stale fallback copies. A corrupt archive is preserved rather than overwritten. Database success is acknowledged only when its transaction commits. These browser databases are local to that browser profile and origin, not a replacement for session exports or a shared pharmacy archive.

If all destinations fail, the correction and notes remain visible and **Download this report** writes an individual case bundle without clearing the form or claiming archive success. Verify the downloaded file before closing. This manual file includes original order text and may contain PHI; keep it in approved local storage. The automatic pilot journal records only the report-save outcome/destination, never report contents. Do not clear browser data to fix a full store: that would remove reports and custom codes.
