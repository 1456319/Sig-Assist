Sig-Assist public demo v0.1.12
Build: 930d219c811952e1472d737686d0f27ff2d893a132cd90f82819ad9ca39c74f5
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
