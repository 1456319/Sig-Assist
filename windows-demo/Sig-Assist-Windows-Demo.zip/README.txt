Sig-Assist public demo v0.1.13
Build: 0171e971db15a0befe81ebe330645b17bd244e8746eab51facb61aa565b4c02a
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
