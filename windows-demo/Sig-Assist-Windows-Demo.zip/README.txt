Sig-Assist public demo v0.1.13
Build: ce1bf1088196835bed0e8c4302d177058f423530005ce7adcc7a589d20b323ad
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
