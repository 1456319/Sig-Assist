Sig-Assist public demo v0.1.15
Build: d2fe7592d876ff0f548c32fab2a3aa9caa90ac66a4022d2b3d4516147fa9dc5a
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
