Sig-Assist public demo v0.1.5
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
