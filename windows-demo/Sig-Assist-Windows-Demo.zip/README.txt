Sig-Assist public demo v0.1.17
Build: 8305676344df4314ae96885503d7faa43e2c20468442bb78f6fd49da3c8315a1
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
