Sig-Assist public demo v0.1.18
Build: 3fba289f3e197572afcd640965403c3dd6cfd8646f84089b8c8f7f139b0914c3
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
