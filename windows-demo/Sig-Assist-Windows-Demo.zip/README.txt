Sig-Assist public demo v0.1.16
Build: 1f5538da0098f87b1e33987cfe611062341f131177d8a07ca1c39fe41d049ace
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
