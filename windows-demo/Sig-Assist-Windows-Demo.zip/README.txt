Sig-Assist public demo v0.1.17
Build: aba60f0b7ff90854e5419512c83955d0a1fe77bcded6769a9fa16c4b267fa4e7
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
