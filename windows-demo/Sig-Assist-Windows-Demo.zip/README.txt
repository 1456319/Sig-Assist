Sig-Assist public demo v0.1.13
Build: 63550207f9198242917df0f25f087de5a52db8462cd762f9a129f66a1317a9a2
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
