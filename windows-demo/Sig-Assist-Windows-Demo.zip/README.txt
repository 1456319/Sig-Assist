Sig-Assist public demo v0.1.11
Build: da07a76a89a47cec90e123f0af7fe9b5ee2aed03d939515f174bddba05bc229e
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
