Sig-Assist public demo v0.1.11
Build: bde1fcb32c9a10b82bdbe25cdff241d245a94ba0dbc0cda3e078859bb0fa4188
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
