Sig-Assist public demo v0.1.13
Build: 784628b2c360d7dfeb5a0c324fbcfed15683aeac59a325e8b4ce47dafa8b98fa
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
