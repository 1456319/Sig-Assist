Sig-Assist public demo v0.1.21
Build: ecda57d3e64e30a6f33576206ae8a886879316005735002504a9256a9efb6c9f
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
