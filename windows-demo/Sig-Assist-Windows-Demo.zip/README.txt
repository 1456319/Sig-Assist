Sig-Assist public demo v0.1.12
Build: eaa14600b4319d7d31a6fbf80b72fdc65c7fdf922c7ac641139e32d59fe6039d
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
