Sig-Assist public demo v0.1.13
Build: 23243dc0f59e95ad423f6d7fcb06f0fb7bf7fe8a5031dcdb05dff21345305cfd
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
