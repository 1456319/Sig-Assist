Sig-Assist public demo v0.1.15
Build: 1e465879babbe90cf3f39466b0e556adbec673bab9c3db827200c046c226c9e5
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
