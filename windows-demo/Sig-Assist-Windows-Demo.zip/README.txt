Sig-Assist public demo v0.1.13
Build: 18e6086f7efb258a4ec361adfa0645b0199724357e8b64dfeb43a75883520c58
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
