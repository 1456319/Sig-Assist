Sig-Assist public demo v0.1.20
Build: c8940f3cf7c9062ca049b6f0c8555b7f53c31853f28914554698daea4243cd7c
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
