Sig-Assist public demo v0.1.15
Build: 24300a9d5f23c9a9abc23a3de2779fb3d2f570c85966771a3d7f2e5e3ffcfa19
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
