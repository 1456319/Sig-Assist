Sig-Assist public demo v0.1.13
Build: 2a363ab520690054ce800b7b88953d02ea9e7fdfcfe000e48f26e8fbb4555dfd
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
