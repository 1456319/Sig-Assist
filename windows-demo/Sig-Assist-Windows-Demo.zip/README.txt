Sig-Assist public demo v0.1.16
Build: 1ba9dbed1a9bbf69f4d5a4beeb54f579727a25207c6b60dc892da03e834ef0d7
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
