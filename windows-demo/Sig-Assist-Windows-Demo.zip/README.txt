Sig-Assist public demo v0.1.13
Build: 6197dbf2ca1af40ca15c6ff2636f68ca8cfc244fe7cf584ce01517ceccbdc7dd
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
