Sig-Assist public demo v0.1.17
Build: ff9daa2db1526f90d70313bedfbaba9ff6132e2e643a7e0b9785ff95ce315082
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
