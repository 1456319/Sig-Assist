Sig-Assist public demo v0.1.16
Build: ba215d488b002d7764d463706fc54d5ed52b0273fe30d2812b4fb56aca10545e
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
