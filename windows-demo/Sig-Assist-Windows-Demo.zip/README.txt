Sig-Assist public demo v0.1.13
Build: 1e1561461c2bbc4bb9ca00e58b309fcf141a810968069a5312daf334208b2bcc
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
