Sig-Assist public demo v0.1.11
Build: 3f5d71dba6b8b9a0a1fb93c9737acbba98d3651e3708485f1fa84157603d756b
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
