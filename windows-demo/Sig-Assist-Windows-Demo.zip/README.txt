Sig-Assist public demo v0.1.17
Build: fa80fb481ed474287d087f1ebd1b032465c1fa5966e2e3602b3f8cb23b780913
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
