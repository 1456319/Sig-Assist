Sig-Assist public demo v0.1.19
Build: f58da098947714433a93bdd970a0a3106d81031fd57c66b061b9b1e1065c4b6a
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
