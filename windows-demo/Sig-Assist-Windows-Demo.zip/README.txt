Sig-Assist public demo v0.1.15
Build: 37e170850a88e914a2c6c15f0552f17e6e70b3c3f1c703ea03bb0801881f0bf8
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
