Sig-Assist public demo v0.1.22
Build: efe4425f21a5d34c724e3a03bfb26e5e3d142acb195a17ef45f615de0c56f3c3
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
