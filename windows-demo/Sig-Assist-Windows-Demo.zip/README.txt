Sig-Assist public demo v0.1.10
Build: 3184b601a62dbf44632ed1feb55bbe76e4748140056681ab96887b7bf03a5c7b
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
