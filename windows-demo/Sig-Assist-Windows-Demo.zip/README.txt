Sig-Assist public demo v0.1.14
Build: b16a60d0bf56b8931ef28d49476b1baf00cf26111a298af9427aed88b4e5a980
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
