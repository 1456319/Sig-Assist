Sig-Assist public demo v0.1.13
Build: 2dc2f20248fedbdd20d1682a0751f46d9610ff365e2083f9605d0e47a5d51ad3
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
