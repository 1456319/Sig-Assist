Sig-Assist public demo v0.1.13
Build: 4a712c44de166d737403e3f8ba78932b41b1b947955e5471f9199117c539f35c
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
