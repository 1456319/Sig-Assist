Sig-Assist public demo v0.1.11
Build: cefc3389274de8afc66a8e3826fef8d9b3e449b4916c3169262d9b46464157a5
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
