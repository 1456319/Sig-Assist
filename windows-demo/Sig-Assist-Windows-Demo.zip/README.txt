Sig-Assist public demo v0.1.11
Build: 630892ed626a5439abe8822fdae5ed85f6f5de4fe215cdb58dd5cced5983598a
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
