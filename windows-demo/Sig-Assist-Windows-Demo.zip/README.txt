Sig-Assist public demo v0.1.11
Build: 2953b769e8f3d892233df7ba5518555fa6b29387a4050ca564e1bb6948971ded
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
