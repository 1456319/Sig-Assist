Sig-Assist public demo v0.1.10
Build: 07254f23621e9352dcb3fe6d11df117280260e884dbed9fff28503e6b2d8c57c
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
