Sig-Assist public demo v0.1.13
Build: d4cc532bd3a0f02d56954c4684e0ff5d02e9ea836a595fb11ca1281a2d6d99d1
Extract the ZIP and run Start-Sig-Assist.bat for the offline demo.
For desktop access run Start-Iguana-Connector.bat in the same Windows session.
Enter your Iguana server URL in Live connection settings if you use live lookup.
